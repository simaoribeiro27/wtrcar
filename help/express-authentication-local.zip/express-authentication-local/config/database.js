module.exports = {
  url: 'mongodb://localhost/expressauth',
};
